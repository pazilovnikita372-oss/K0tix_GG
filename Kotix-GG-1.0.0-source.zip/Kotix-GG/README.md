# Kotix-GG 1.0.0

Fabric client project for Minecraft Java Edition 1.21.4.

## Version lock

- Minecraft: 1.21.4
- Fabric Loader: 0.19.5
- Fabric API: 0.119.4+1.21.4
- Yarn: 1.21.4+build.8
- Fabric Loom: 1.17-SNAPSHOT
- Java: 21
- Gradle: 8.10.2

## Build

Linux/macOS:
```sh
chmod +x gradlew build.sh
./build.sh
```

Windows:
```bat
build.bat
```

Output:
`build/libs/kotixgg-1.0.0.jar`

## GUI

Right Shift opens the ClickGUI. Category panels can be dragged. Left click toggles modules, right click expands settings. The GUI uses a dark translucent style with #00FFAA accent and enlarged controls for touch input.

## Safety / compatibility

The project intentionally avoids raw OpenGL calls and custom network packets. Anti-crash components are local exception guards. Network-packet spoofing and anti-cheat evasion are not implemented in this baseline, because such behavior is server-specific and can violate server rules.

The module catalog contains the requested names and safe extension points so individual client-side behavior can be added without changing the GUI architecture.
