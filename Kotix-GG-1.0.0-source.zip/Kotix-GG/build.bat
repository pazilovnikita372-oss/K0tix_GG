@echo off
call gradlew.bat clean build
if errorlevel 1 exit /b %errorlevel%
echo Build complete: build\libs\kotixgg-1.0.0.jar
