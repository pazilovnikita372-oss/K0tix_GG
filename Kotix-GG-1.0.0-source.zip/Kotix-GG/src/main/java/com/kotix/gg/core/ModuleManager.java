package com.kotix.gg.core;

import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.kotix.gg.modules.KillAura;
import com.kotix.gg.modules.AutoClicker;
import com.kotix.gg.modules.ReachHelper;
import com.kotix.gg.modules.CriticalHelper;
import com.kotix.gg.modules.TriggerBot;
import com.kotix.gg.modules.AutoBlock;
import com.kotix.gg.modules.AntiKnockback;
import com.kotix.gg.modules.VelocityHelper;
import com.kotix.gg.modules.FastSwitch;
import com.kotix.gg.modules.RotationSpoof;
import com.kotix.gg.modules.HumanJitter;
import com.kotix.gg.modules.Freecam;
import com.kotix.gg.modules.EspBox;
import com.kotix.gg.modules.Tracers;
import com.kotix.gg.modules.ChinaHat;
import com.kotix.gg.modules.TargetHud;
import com.kotix.gg.modules.Watermark;
import com.kotix.gg.modules.StorageEsp;
import com.kotix.gg.modules.Fullbright;
import com.kotix.gg.modules.BlockHighlight;
import com.kotix.gg.modules.LineTracer;
import com.kotix.gg.modules.ItemEsp;
import com.kotix.gg.modules.PlayerInfo;
import com.kotix.gg.modules.HoleEsp;
import com.kotix.gg.modules.SkeletonEsp;
import com.kotix.gg.modules.NameTags;
import com.kotix.gg.modules.DamageTint;
import com.kotix.gg.modules.CrystalEsp;
import com.kotix.gg.modules.ArrowTrails;
import com.kotix.gg.modules.Zoom;
import com.kotix.gg.modules.NoRender;
import com.kotix.gg.modules.AntiBlind;
import com.kotix.gg.modules.AntiFog;
import com.kotix.gg.modules.Xray;
import com.kotix.gg.modules.Chams;
import com.kotix.gg.modules.Breadcrumbs;
import com.kotix.gg.modules.HealthTag;
import com.kotix.gg.modules.Tracers2D;
import com.kotix.gg.modules.Nuker;
import com.kotix.gg.modules.BrightnessBoost;
import com.kotix.gg.modules.BlockOverlay;
import com.kotix.gg.modules.AutoArmor;
import com.kotix.gg.modules.AntiCrash;
import com.kotix.gg.modules.PacketGuard;
import com.kotix.gg.modules.ReachGuard;
import com.kotix.gg.modules.GCDAnalyzer;
import com.kotix.gg.modules.PingSpoof;
import com.kotix.gg.modules.AntiVanish;
import com.kotix.gg.modules.SandboxGuardModule;
import com.kotix.gg.modules.RealWorldBypass;
import com.kotix.gg.modules.CrystalAura;
import com.kotix.gg.modules.AutoAnchor;
import com.kotix.gg.modules.AutoTrap;
import com.kotix.gg.modules.AutoCity;
import com.kotix.gg.modules.Surround;
import com.kotix.gg.modules.HoleFiller;
import com.kotix.gg.modules.BedAura;
import com.kotix.gg.modules.AutoTotem;
import com.kotix.gg.modules.PistonAura;
import com.kotix.gg.modules.PurpurAura;
import com.kotix.gg.modules.AutoCrystal;
import com.kotix.gg.modules.SurroundPlus;

public final class ModuleManager {
    public static final Logger LOGGER = LoggerFactory.getLogger("Kotix-GG");
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean initialized;

    private ModuleManager() {
    }

    /** Инициализирует каталог модулей один раз. */
    public static synchronized void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        register(new KillAura());
        register(new AutoClicker());
        register(new ReachHelper());
        register(new CriticalHelper());
        register(new TriggerBot());
        register(new AutoBlock());
        register(new AntiKnockback());
        register(new VelocityHelper());
        register(new FastSwitch());
        register(new RotationSpoof());
        register(new HumanJitter());
        register(new Freecam());
        register(new EspBox());
        register(new Tracers());
        register(new ChinaHat());
        register(new TargetHud());
        register(new Watermark());
        register(new StorageEsp());
        register(new Fullbright());
        register(new BlockHighlight());
        register(new LineTracer());
        register(new ItemEsp());
        register(new PlayerInfo());
        register(new HoleEsp());
        register(new SkeletonEsp());
        register(new NameTags());
        register(new DamageTint());
        register(new CrystalEsp());
        register(new ArrowTrails());
        register(new Zoom());
        register(new NoRender());
        register(new AntiBlind());
        register(new AntiFog());
        register(new Xray());
        register(new Chams());
        register(new Breadcrumbs());
        register(new HealthTag());
        register(new Tracers2D());
        register(new Nuker());
        register(new BrightnessBoost());
        register(new BlockOverlay());
        register(new AutoArmor());
        register(new AntiCrash());
        register(new PacketGuard());
        register(new ReachGuard());
        register(new GCDAnalyzer());
        register(new PingSpoof());
        register(new AntiVanish());
        register(new SandboxGuardModule());
        register(new RealWorldBypass());
        register(new CrystalAura());
        register(new AutoAnchor());
        register(new AutoTrap());
        register(new AutoCity());
        register(new Surround());
        register(new HoleFiller());
        register(new BedAura());
        register(new AutoTotem());
        register(new PistonAura());
        register(new PurpurAura());
        register(new AutoCrystal());
        register(new SurroundPlus());
    }

    private static void register(Module module) {
        MODULES.add(module);
    }

    /** Возвращает неизменяемый список модулей. */
    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    /** Возвращает модули указанной категории. */
    public static List<Module> byCategory(Category category) {
        return MODULES.stream().filter(module -> module.getCategory() == category).toList();
    }

    /** Безопасно вызывает tick у всех модулей. */
    public static void tick(MinecraftClient client) {
        for (Module module : MODULES) {
            module.tickSafe(client);
        }
    }
}
