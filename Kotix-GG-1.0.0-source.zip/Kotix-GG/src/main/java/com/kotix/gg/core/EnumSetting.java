package com.kotix.gg.core;

public final class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final E[] values;

    public EnumSetting(String name, E value, Class<E> type) {
        super(name, value);
        this.values = type.getEnumConstants();
    }

    public E[] getValues() {
        return values.clone();
    }

    public void cycle() {
        if (values.length == 0) {
            return;
        }
        int next = (getValue().ordinal() + 1) % values.length;
        setValue(values[next]);
    }
}
