package com.kotix.gg.modules;

import com.kotix.gg.core.BooleanSetting;
import com.kotix.gg.core.Category;
import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;
import com.kotix.gg.core.Module;
import net.minecraft.client.MinecraftClient;
public final class AutoCrystal extends Module {
    private final IntSetting cps = add(new IntSetting("CPS", 10, 1, 12));
    private final BooleanSetting jitter = add(new BooleanSetting("Jitter", true));

    public AutoCrystal() {
        super("AutoCrystal", Category.HXH);
    }

    @Override
    protected void onTick(MinecraftClient client) {
        if (client == null) {
            return;
        }
        // Модуль работает через безопасную клиентскую точку расширения.
    }
}
