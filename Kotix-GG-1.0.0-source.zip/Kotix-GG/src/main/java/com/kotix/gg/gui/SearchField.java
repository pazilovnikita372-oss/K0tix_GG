package com.kotix.gg.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

public final class SearchField {
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean focused;
    private final StringBuilder value = new StringBuilder();

    public void setBounds(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public String getQuery() {
        return value.toString();
    }

    public void render(DrawContext context, int mouseX, int mouseY) {
        context.fill(x, y, x + width, y + height, 0xFF202020);
        context.drawText(MinecraftClient.getInstance().textRenderer,
                value.isEmpty() ? "Search..." : value.toString(),
                x + 7, y + 8, focused ? 0xFF00FFAA : 0xFFFFFFFF, false);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        focused = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        return focused;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!focused) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !value.isEmpty()) {
            value.deleteCharAt(value.length() - 1);
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (!focused) {
            return false;
        }
        if (Character.isLetterOrDigit(chr) || chr == ' ' || chr == '_' || chr == '-') {
            if (value.length() < 32) {
                value.append(chr);
            }
            return true;
        }
        return false;
    }
}
