package com.kotix.gg.safety;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class SandboxGuard {
    private static boolean warned;

    private SandboxGuard() {
    }

    /** Сбрасывает состояние предупреждения. */
    public static void install() {
        warned = false;
    }

    /** Возвращает true для одиночной игры. */
    public static boolean isSingleplayer(MinecraftClient client) {
        return client != null && client.isInSingleplayer();
    }

    /** Показывает одно предупреждение в мультиплеере. */
    public static void warnMultiplayer(MinecraftClient client) {
        if (warned || client == null || client.isInSingleplayer() || client.player == null) {
            return;
        }
        warned = true;
        client.player.sendMessage(
                Text.literal("[Kotix-GG] Мультиплеер: используйте клиент только там, где это разрешено сервером."),
                false
        );
    }
}
