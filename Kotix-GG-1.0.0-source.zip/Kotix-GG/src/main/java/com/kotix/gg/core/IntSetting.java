package com.kotix.gg.core;

public final class IntSetting extends Setting<Integer> {
    private final int min;
    private final int max;

    public IntSetting(String name, int value, int min, int max) {
        super(name, Math.max(min, Math.min(max, value)));
        this.min = min;
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public void setClamped(int value) {
        setValue(Math.max(min, Math.min(max, value)));
    }
}
