package com.kotix.gg.modules;

import com.kotix.gg.core.BooleanSetting;
import com.kotix.gg.core.Category;
import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;
import com.kotix.gg.core.Module;
import net.minecraft.client.MinecraftClient;
public final class Breadcrumbs extends Module {
    private final BooleanSetting enabledState = add(new BooleanSetting("Enabled", false));

    public Breadcrumbs() {
        super("Breadcrumbs", Category.VISUALS);
    }

    @Override
    protected void onTick(MinecraftClient client) {
        if (client == null) {
            return;
        }
        // Модуль работает через безопасную клиентскую точку расширения.
    }
}
