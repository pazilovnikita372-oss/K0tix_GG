package com.kotix.gg.core;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public final String getName() {
        return name;
    }

    public final Category getCategory() {
        return category;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    protected final <T extends Setting<?>> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    /** Переключает состояние модуля. */
    public final void toggle() {
        setEnabled(!enabled);
    }

    /** Устанавливает состояние модуля и безопасно вызывает жизненный цикл. */
    public final void setEnabled(boolean state) {
        if (enabled == state) {
            return;
        }
        enabled = state;
        try {
            if (state) {
                onEnable();
            } else {
                onDisable();
            }
        } catch (Throwable throwable) {
            ModuleManager.LOGGER.error("Ошибка модуля {}", name, throwable);
            enabled = false;
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    /** Вызывается для активного модуля каждый клиентский тик. */
    protected void onTick(MinecraftClient client) {
    }

    /** Безопасная оболочка тика модуля. */
    public final void tickSafe(MinecraftClient client) {
        if (!enabled) {
            return;
        }
        try {
            onTick(client);
        } catch (Throwable throwable) {
            ModuleManager.LOGGER.error("Ошибка tick модуля {}", name, throwable);
        }
    }
}
