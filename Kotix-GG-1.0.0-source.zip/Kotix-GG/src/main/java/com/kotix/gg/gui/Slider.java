package com.kotix.gg.gui;

import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;

public final class Slider {
    private Slider() {
    }

    /** Изменяет целочисленный слайдер по позиции мыши. */
    public static void setFromMouse(IntSetting setting, double mouseX, double left, double width) {
        if (setting == null || width <= 0.0) {
            return;
        }
        double t = Math.max(0.0, Math.min(1.0, (mouseX - left) / width));
        setting.setClamped((int) Math.round(setting.getMin() + t * (setting.getMax() - setting.getMin())));
    }

    /** Изменяет float-слайдер по позиции мыши. */
    public static void setFromMouse(FloatSetting setting, double mouseX, double left, double width) {
        if (setting == null || width <= 0.0) {
            return;
        }
        double t = Math.max(0.0, Math.min(1.0, (mouseX - left) / width));
        setting.setClamped((float) (setting.getMin() + t * (setting.getMax() - setting.getMin())));
    }
}
