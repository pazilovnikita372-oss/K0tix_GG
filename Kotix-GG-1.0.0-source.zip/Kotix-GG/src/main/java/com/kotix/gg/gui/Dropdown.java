package com.kotix.gg.gui;

import com.kotix.gg.core.EnumSetting;

public final class Dropdown {
    private Dropdown() {
    }

    /** Переключает значение перечисления. */
    public static void next(EnumSetting<?> setting) {
        if (setting != null) {
            setting.cycle();
        }
    }
}
