package com.kotix.gg.algorithm;

public final class GCDAnalyzer {
    private GCDAnalyzer() {
    }

    /** Проверяет, близок ли угол к заданной сетке. */
    public static boolean isGridAligned(float angle, float grid, float epsilon) {
        if (!Float.isFinite(angle) || !Float.isFinite(grid) || grid <= 0.0f) {
            return false;
        }
        float q = angle / grid;
        return Math.abs(q - Math.round(q)) <= epsilon;
    }

    /** Округляет изменение угла к сетке. */
    public static float normalizeStep(float delta, float grid) {
        if (!Float.isFinite(delta) || !Float.isFinite(grid) || grid <= 0.0f) {
            return 0.0f;
        }
        return Math.round(delta / grid) * grid;
    }
}
