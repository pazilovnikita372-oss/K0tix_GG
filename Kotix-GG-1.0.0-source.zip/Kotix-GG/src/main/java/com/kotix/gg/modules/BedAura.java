package com.kotix.gg.modules;

import com.kotix.gg.core.BooleanSetting;
import com.kotix.gg.core.Category;
import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;
import com.kotix.gg.core.Module;
import net.minecraft.client.MinecraftClient;
public final class BedAura extends Module {
    private final BooleanSetting enabledState = add(new BooleanSetting("Enabled", false));

    public BedAura() {
        super("BedAura", Category.HXH);
    }

    @Override
    protected void onTick(MinecraftClient client) {
        if (client == null) {
            return;
        }
        // Модуль работает через безопасную клиентскую точку расширения.
    }
}
