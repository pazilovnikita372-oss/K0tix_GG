package com.kotix.gg.algorithm;

public final class RotationController {
    private float yaw;
    private float pitch;

    /** Плавно изменяет локальное состояние ротации. */
    public void update(float targetYaw, float targetPitch, float smoothing) {
        float s = Math.max(0.01f, Math.min(1.0f, smoothing));
        yaw += wrap(targetYaw - yaw) * s;
        pitch += (targetPitch - pitch) * s;
        pitch = Math.max(-90.0f, Math.min(90.0f, pitch));
    }

    private float wrap(float value) {
        float result = value % 360.0f;
        if (result > 180.0f) {
            result -= 360.0f;
        }
        if (result < -180.0f) {
            result += 360.0f;
        }
        return result;
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }
}
