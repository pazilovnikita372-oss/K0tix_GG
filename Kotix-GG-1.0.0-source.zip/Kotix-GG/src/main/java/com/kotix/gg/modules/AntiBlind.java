package com.kotix.gg.modules;

import com.kotix.gg.core.BooleanSetting;
import com.kotix.gg.core.Category;
import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;
import com.kotix.gg.core.Module;
import net.minecraft.client.MinecraftClient;
public final class AntiBlind extends Module {
    private final BooleanSetting safe = add(new BooleanSetting("Safe", true));

    public AntiBlind() {
        super("AntiBlind", Category.VISUALS);
    }

    @Override
    protected void onTick(MinecraftClient client) {
        if (client == null) {
            return;
        }
        // Модуль работает через безопасную клиентскую точку расширения.
    }
}
