package com.kotix.gg.core;

public enum Category {
    COMBAT,
    MOVEMENT,
    VISUALS,
    PLAYER,
    MISC,
    HXH
}
