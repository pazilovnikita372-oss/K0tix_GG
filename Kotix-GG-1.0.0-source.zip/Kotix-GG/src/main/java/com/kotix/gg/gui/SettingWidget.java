package com.kotix.gg.gui;

import com.kotix.gg.core.Module;
import net.minecraft.client.gui.DrawContext;

public final class SettingWidget {
    private SettingWidget() {
    }

    /** Общая точка для расширения виджетов настроек. */
    public static void render(DrawContext context, Module module, int x, int y, int width) {
        ModuleButton unused = null;
        // Основная отрисовка выполняется ModuleButton, чтобы сохранить состояние раскрытия.
    }
}
