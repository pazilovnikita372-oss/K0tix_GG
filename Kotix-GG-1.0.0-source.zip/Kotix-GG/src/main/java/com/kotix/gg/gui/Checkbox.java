package com.kotix.gg.gui;

import com.kotix.gg.core.BooleanSetting;

public final class Checkbox {
    private Checkbox() {
    }

    /** Переключает чекбокс. */
    public static void toggle(BooleanSetting setting) {
        if (setting != null) {
            setting.toggle();
        }
    }
}
