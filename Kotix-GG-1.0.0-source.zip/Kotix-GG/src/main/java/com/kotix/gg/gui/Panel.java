package com.kotix.gg.gui;

import com.kotix.gg.core.Category;
import com.kotix.gg.core.Module;
import com.kotix.gg.core.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ClickType;
import java.util.ArrayList;
import java.util.List;

public final class Panel {
    private final Category category;
    private final List<ModuleButton> buttons = new ArrayList<>();
    private double x;
    private double y;
    private double dragX;
    private double dragY;
    private boolean dragging;

    public Panel(Category category, double x, double y) {
        this.category = category;
        this.x = x;
        this.y = y;
        for (Module module : ModuleManager.byCategory(category)) {
            buttons.add(new ModuleButton(module, this));
        }
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta, String query) {
        if (dragging) {
            x = mouseX - dragX;
            y = mouseY - dragY;
        }

        int left = (int) x;
        int top = (int) y;
        int rows = 0;
        for (ModuleButton button : buttons) {
            if (button.matches(query)) {
                rows++;
            }
        }

        int height = 26 + rows * 28;
        context.fill(left, top, left + 166, top + height, 0xE8151515);
        context.fill(left, top, left + 166, top + 26, 0xF0222222);
        context.fill(left, top, left + 3, top + 26, 0xFF00FFAA);
        context.drawText(MinecraftClient.getInstance().textRenderer, category.name(), left + 10, top + 9, 0xFFFFFFFF, true);

        int rowY = top + 28;
        for (ModuleButton button : buttons) {
            if (!button.matches(query)) {
                continue;
            }
            button.setY(rowY);
            button.render(context, mouseX, mouseY, delta);
            rowY += 28;
        }
    }

    public boolean mouseClicked(double mouseX, double mouseY, ClickType type) {
        if (inside(mouseX, mouseY, x, y, 166, 26)) {
            dragging = true;
            dragX = mouseX - x;
            dragY = mouseY - y;
            return true;
        }

        for (ModuleButton button : buttons) {
            if (button.mouseClicked(mouseX, mouseY, type)) {
                return true;
            }
        }
        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        for (ModuleButton moduleButton : buttons) {
            moduleButton.mouseReleased(mouseX, mouseY, button);
        }
    }

    private static boolean inside(double mx, double my, double left, double top, double width, double height) {
        return mx >= left && mx <= left + width && my >= top && my <= top + height;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
