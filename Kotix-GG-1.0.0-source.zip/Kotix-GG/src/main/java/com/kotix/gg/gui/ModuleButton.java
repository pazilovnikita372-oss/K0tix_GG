package com.kotix.gg.gui;

import com.kotix.gg.core.BooleanSetting;
import com.kotix.gg.core.EnumSetting;
import com.kotix.gg.core.FloatSetting;
import com.kotix.gg.core.IntSetting;
import com.kotix.gg.core.Module;
import com.kotix.gg.core.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.ClickType;
import net.minecraft.client.gui.DrawContext;

public final class ModuleButton {
    private final Module module;
    private final Panel panel;
    private int y;
    private boolean expanded;

    public ModuleButton(Module module, Panel panel) {
        this.module = module;
        this.panel = panel;
    }

    public void setY(int y) {
        this.y = y;
    }

    public boolean matches(String query) {
        return query == null || query.isBlank()
                || module.getName().toLowerCase().contains(query.toLowerCase());
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = (int) panel.getX();
        boolean hovered = mouseX >= x && mouseX <= x + 166 && mouseY >= y && mouseY <= y + 25;
        int background = module.isEnabled() ? 0xFF00FFAA : (hovered ? 0xFF292929 : 0xFF202020);
        int text = module.isEnabled() ? 0xFF101010 : 0xFFFFFFFF;

        context.fill(x + 4, y, x + 162, y + 25, background);
        context.drawText(MinecraftClient.getInstance().textRenderer, module.getName(), x + 10, y + 9, text, false);

        if (expanded) {
            int settingY = y + 27;
            for (Setting<?> setting : module.getSettings()) {
                renderSetting(context, setting, x + 8, settingY, 150);
                settingY += 22;
            }
        }
    }

    private void renderSetting(DrawContext context, Setting<?> setting, int x, int y, int width) {
        int color = 0xFF1C1C1C;
        context.fill(x, y, x + width, y + 19, color);
        String value = String.valueOf(setting.getValue());
        context.drawText(MinecraftClient.getInstance().textRenderer,
                setting.getName() + ": " + value, x + 5, y + 6, 0xFFFFFFFF, false);

        if (setting instanceof BooleanSetting booleanSetting) {
            context.fill(x + width - 16, y + 4, x + width - 5, y + 15,
                    booleanSetting.getValue() ? 0xFF00FFAA : 0xFF555555);
        } else if (setting instanceof IntSetting intSetting) {
            drawBar(context, x + 5, y + 16, width - 10,
                    (intSetting.getValue() - intSetting.getMin()) / (float) Math.max(1, intSetting.getMax() - intSetting.getMin()));
        } else if (setting instanceof FloatSetting floatSetting) {
            drawBar(context, x + 5, y + 16, width - 10,
                    (floatSetting.getValue() - floatSetting.getMin()) / Math.max(0.001f, floatSetting.getMax() - floatSetting.getMin()));
        } else if (setting instanceof EnumSetting<?>) {
            context.fill(x + width - 20, y + 4, x + width - 5, y + 15, 0xFF00FFAA);
        }
    }

    private void drawBar(DrawContext context, int x, int y, int width, float progress) {
        int filled = Math.max(0, Math.min(width, (int) (width * progress)));
        context.fill(x, y, x + width, y + 2, 0xFF404040);
        context.fill(x, y, x + filled, y + 2, 0xFF00FFAA);
    }

    public boolean mouseClicked(double mouseX, double mouseY, ClickType type) {
        int x = (int) panel.getX();
        if (mouseX < x + 2 || mouseX > x + 164 || mouseY < y || mouseY > y + 25) {
            return false;
        }

        if (type == ClickType.LEFT) {
            module.toggle();
            return true;
        }
        if (type == ClickType.RIGHT) {
            expanded = !expanded;
            return true;
        }
        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
    }
}
