package com.kotix.gg.algorithm;

public final class HumanMotionModel {
    private final double seed;

    public HumanMotionModel(long seed) {
        this.seed = seed * 0.000001;
    }

    /** Возвращает плавное локальное значение шума для анимаций. */
    public float noise(double time) {
        double a = Math.sin(time * 1.73 + seed) * 0.5;
        double b = Math.sin(time * 0.71 + seed * 2.0) * 0.25;
        return (float) (a + b);
    }
}
