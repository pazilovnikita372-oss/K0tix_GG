package com.kotix.gg.gui;

import com.kotix.gg.core.Category;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.ClickType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public final class ClickGUI extends Screen {
    private final List<Panel> panels = new ArrayList<>();
    private final SearchField searchField = new SearchField();
    private long openedAt;

    public ClickGUI() {
        super(Text.literal("Kotix-GG"));
        int x = 24;
        for (Category category : Category.values()) {
            panels.add(new Panel(category, x, 48));
            x += 178;
        }
    }

    @Override
    protected void init() {
        openedAt = System.currentTimeMillis();
        searchField.setBounds(24, 16, Math.min(360, width - 48), 24);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        try {
            float progress = Math.min(1.0f, (System.currentTimeMillis() - openedAt) / 180.0f);
            int alpha = (int) (185.0f * progress);
            context.fill(0, 0, width, height, (alpha << 24) | 0x00151515);

            // Псевдо-blur без прямых GL-вызовов: затемнение безопасно на всех режимах.
            context.fill(0, 0, width, height, 0x30151515);
            context.drawText(textRenderer, "Kotix-GG", 24, 3, 0xFF00FFAA, true);

            searchField.render(context, mouseX, mouseY);
            for (Panel panel : panels) {
                panel.render(context, mouseX, mouseY, delta, searchField.getQuery());
            }
        } catch (Throwable throwable) {
            // Рендер GUI никогда не должен ломать игровой клиент.
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        try {
            if (searchField.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
            ClickType type = button == GLFW.GLFW_MOUSE_BUTTON_RIGHT ? ClickType.RIGHT : ClickType.LEFT;
            for (Panel panel : panels) {
                if (panel.mouseClicked(mouseX, mouseY, type)) {
                    return true;
                }
            }
        } catch (Throwable throwable) {
            // Ошибка одного элемента не должна закрывать весь экран.
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (Panel panel : panels) {
            panel.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return searchField.keyPressed(keyCode, scanCode, modifiers)
                || super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        return searchField.charTyped(chr, modifiers) || super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
