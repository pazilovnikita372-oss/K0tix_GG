package com.kotix.gg.core;

public final class FloatSetting extends Setting<Float> {
    private final float min;
    private final float max;

    public FloatSetting(String name, float value, float min, float max) {
        super(name, Math.max(min, Math.min(max, value)));
        this.min = min;
        this.max = max;
    }

    public float getMin() {
        return min;
    }

    public float getMax() {
        return max;
    }

    public void setClamped(float value) {
        setValue(Math.max(min, Math.min(max, value)));
    }
}
