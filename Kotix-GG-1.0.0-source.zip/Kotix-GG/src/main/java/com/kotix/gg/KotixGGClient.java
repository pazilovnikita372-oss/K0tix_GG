package com.kotix.gg;

import com.kotix.gg.core.ModuleManager;
import com.kotix.gg.gui.ClickGUI;
import com.kotix.gg.safety.SandboxGuard;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class KotixGGClient implements ClientModInitializer {
    public static final String MOD_ID = "kotixgg";
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        SandboxGuard.install();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kotixgg.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.kotixgg"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey != null && openGuiKey.wasPressed()) {
                openGui(client);
            }
            ModuleManager.tick(client);
        });
    }

    private static void openGui(MinecraftClient client) {
        if (client == null) {
            return;
        }
        try {
            client.setScreen(new ClickGUI());
        } catch (Throwable throwable) {
            ModuleManager.LOGGER.error("Не удалось открыть ClickGUI", throwable);
        }
    }
}
