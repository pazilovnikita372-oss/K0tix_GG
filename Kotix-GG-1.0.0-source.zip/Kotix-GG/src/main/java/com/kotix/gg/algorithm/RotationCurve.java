package com.kotix.gg.algorithm;

public final class RotationCurve {
    private RotationCurve() {
    }

    /** Catmull-Rom интерполяция. */
    public static float catmullRom(float p0, float p1, float p2, float p3, float t) {
        float t2 = t * t;
        float t3 = t2 * t;
        return 0.5f * ((2.0f * p1)
                + (-p0 + p2) * t
                + (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * t2
                + (-p0 + 3.0f * p1 - 3.0f * p2 + p3) * t3);
    }

    /** Cubic Bezier интерполяция. */
    public static float bezier(float p0, float p1, float p2, float p3, float t) {
        float u = 1.0f - t;
        return u * u * u * p0 + 3.0f * u * u * t * p1 + 3.0f * u * t * t * p2 + t * t * t * p3;
    }

    /** Простая spring-damper интерполяция. */
    public static float spring(float current, float target, float velocity, float stiffness, float damping) {
        return current + velocity * (1.0f - damping) + (target - current) * stiffness;
    }
}
