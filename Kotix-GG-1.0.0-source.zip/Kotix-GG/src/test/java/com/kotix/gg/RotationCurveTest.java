package com.kotix.gg;

import com.kotix.gg.algorithm.RotationCurve;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public final class RotationCurveTest {
    @Test
    void bezierEndpointsMatch() {
        assertEquals(0.0f, RotationCurve.bezier(0, 1, 2, 3, 0), 0.0001f);
        assertEquals(3.0f, RotationCurve.bezier(0, 1, 2, 3, 1), 0.0001f);
    }

    @Test
    void catmullMidpointIsFinite() {
        assertTrue(Float.isFinite(RotationCurve.catmullRom(0, 1, 2, 3, 0.5f)));
    }
}
