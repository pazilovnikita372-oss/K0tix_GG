package com.kotix.gg;

import com.kotix.gg.algorithm.GCDAnalyzer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public final class GCDAnalyzerTest {
    @Test
    void alignedAngleIsAccepted() {
        assertTrue(GCDAnalyzer.isGridAligned(1.00f, 0.01f, 0.0001f));
    }

    @Test
    void nonAlignedAngleIsRejected() {
        assertFalse(GCDAnalyzer.isGridAligned(1.005f, 0.01f, 0.0001f));
    }

    @Test
    void normalizeStepRoundsToGrid() {
        assertEquals(1.01f, GCDAnalyzer.normalizeStep(1.006f, 0.01f), 0.0001f);
    }
}
