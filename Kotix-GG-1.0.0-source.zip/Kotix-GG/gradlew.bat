@echo off
setlocal
set "GRADLE_VERSION=8.10.2"
set "GRADLE_DIR=.gradle-local"
set "GRADLE_HOME=%GRADLE_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"

if not exist "%GRADLE_BIN%" (
    if not exist "%GRADLE_DIR%" mkdir "%GRADLE_DIR%"
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile '%GRADLE_DIR%\gradle.zip'; Expand-Archive -Force '%GRADLE_DIR%\gradle.zip' '%GRADLE_DIR%'; Remove-Item '%GRADLE_DIR%\gradle.zip'"
    if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
endlocal
