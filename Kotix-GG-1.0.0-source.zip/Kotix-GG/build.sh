#!/bin/sh
set -eu
chmod +x ./gradlew
./gradlew clean build
